export const yatchUrl = '/api/yacht';

const urls = {
  updateBooking: `${yatchUrl}/updateBookingStatus`,
  deleteYatch: `${yatchUrl}/deleteYatch`
}

export default urls;
