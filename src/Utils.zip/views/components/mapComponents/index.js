import PropTypes from 'prop-types'
import React, {
  useState, useRef,
  memo, useEffect
} from 'react';
import {
  CAvatar,
  CButton,
  CButtonGroup,
  CCard,
  CCardBody,
  CCardFooter,
  CCardHeader,
  CCol,
  CForm,
  CProgress,
  CRow,
  CTable,
  CTableBody,
  CTableDataCell,
  CTableHead,
  CTableHeaderCell,
  CTableRow,
  CCallout,

  CFormControl
} from '@coreui/react'

import CIcon from '@coreui/icons-react'
import {
  GoogleMap, useJsApiLoader, Marker, Autocomplete, InfoWindow, DirectionsService, DirectionsRenderer, Circle, LoadScript, HeatmapLayer
} from '@react-google-maps/api';
import OfficeCard from './OfficeCard'
import ProxyLocations from './ProxyLocations'
import geoshap from './shapedistrict'


const centerProp = {
  lat: 20.5937,
  lng: 78.9629,
};

const libraries = ['places', 'visualization'];
var sv = null;
var panorama = null;
var clickedMarker = null;



export const AutoCompleteComponent = ({ withLatLng, handleAddress, register = {}, error }) => {
  const autoCompltedRef = useRef(null);

  const onLoad = (something) => {
    console.log('something on Load', something);
    autoCompltedRef.current = something;
  };

  const onPlaceChanged = (e) => {
    if (autoCompltedRef.current) {
      const place = autoCompltedRef.current.getPlace();
      console.log("place got >>", place)
      if (place.geometry && place.geometry.location) {
        const lat = place.geometry.location.lat();
        const lng = place.geometry.location.lng();
        console.log({ lat, lng })
        if (withLatLng) withLatLng({ lat, lng });
        const { address_components } = place;
        if (handleAddress) handleAddress(address_components)
      }
    } else {
      console.log('Autocomplete is not loaded yet!');
    }
  };
  var defaultBounds = new window.google.maps.LatLngBounds(
    new window.google.maps.LatLng(24.4211889, 54.4313433) // Dubai area
  );
  const options = {
    location: new window.google.maps.LatLng(24.4211889, 54.4313433),
    bounds: defaultBounds,
    componentRestrictions: { country: 'AE' }
  }


  return (
    <Autocomplete
      onLoad={onLoad}
      onPlaceChanged={onPlaceChanged}
      options={options}
    // fields={['geometry']}
    >
      <CFormControl
        className={error ? "error-input" : ""}
        {...register}
        placeholder="SEARCH PLACE"
        type='text' />
    </Autocomplete>
  );
};


const MapComponent = ({
  type, withLatLng, center = centerProp, markers, handleAddress, proxylocationRountingresult, register, error, officeLocations, currentEmployeeLocations, currentLocations, zoom, onMarkerClickParent
}) => {

  const containerStyle = {
    width: '100%',
    height: '100%',
  };
  const itemsRef = useRef([]);
  const infostreetview = useRef();
  const [mapRef, setMapRef] = useState(null);
  const [streetviewvisible, setStreetviewvisible] = useState('block');
  const [infoLocation, setIntfoLocation] = useState(null);
  const [employeeLocations, setEmployeeLocations] = useState([]);
  const [selectedOffice, setSelectedOffice] = useState(null);

  const [routeResults, setRouteResults] = useState([]);
  const [totalrouteResults, settotalRouteResults] = useState([]);
  const [directionServiceArray, setDirectionServiceArray] = useState([]);
  const [currentcenter, setCurrentcenter] = useState(center);
  const [currentzoom, setZoom] = useState(zoom || 9);
  const [officeLocHistory, setDragedLoctions] = useState([])
  // const  [zoomforradiusLevel, setzoomforradiusLevel] = useState(zoom ||15);



  const callBackOnLoc = (data, status) => {
    console.log('on result >>>>', data, status)

    if (routeResults.length < 2)
      setRouteResults(oldArray => [...oldArray, data]);

  }

  const mapid = ["fcc5a7955fc5718e"];
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: 'AIzaSyDOqjoKY4YFUV3uS23oYocDSp8Rv36yhmQ',
    libraries,
    mapIds: mapid
  });

  useEffect(() => {
    setCurrentcenter(center);
    setZoom(zoom || 9);
  }, [center, zoom]);

  useEffect(() => {
    console.log("do new route >>>", officeLocHistory)
  }, [officeLocHistory])

  useEffect(() => {
    const directionServiceArrayloc = (currentEmployeeLocations || []).map(empLoc => {
      const officeLoc = currentLocations.find(f => f._id == empLoc.businessgroupid);
      const directionServiceOpts = {
        options: {
          destination: { lat: officeLoc.lat, lng: officeLoc.lng },
          travelMode: 'DRIVING',
          origin: { lat: empLoc.lat, lng: empLoc.lng },

        },
        callBackFunction: callBackOnLoc,

      }

      return directionServiceOpts;
      // return ({ lat: destiantion.lat, lng: destiantion.lng });
    });
    setDirectionServiceArray(directionServiceArrayloc);
    setRouteResults(totalrouteResults.filter(routeResultsdata => {

      const emp = (currentEmployeeLocations || []).find((empLoc) => (empLoc.lat == routeResultsdata.request.origin.location.lat() && empLoc.lng == routeResultsdata.request.origin.location.lng()));
      return emp?.businessgroupid == selectedOffice?._id;

    }));
  }, [currentEmployeeLocations, currentLocations])

  // const   clearMarkers =  (oldmarkers)=> {
  //   //debugger;

  //   console.log('markers',oldmarkers.current)
  //   for (let m of oldmarkers.current) {
  //     //debugger;
  //     if(m)
  //     m.marker.visible = true;
  //    // m.setMap(null);
  //   }
  // }


  //   useEffect(() => {

  //     itemsRef.current = itemsRef.current.slice(0,(markers?.length||0));

  //     return ()=> clearMarkers(itemsRef)
  //  }, [markers]);

  //  const   resetZoom  =  (zoomLevel)=> {
  //     //debugger;

  //     console.log('markers',itemsRef.current)
  //     console.log('zoomLevel',zoomLevel)
  //     for (let m of itemsRef.current) {
  //       //debugger;
  //      const currOffice =  markers?.find(((markerdData,i) => markerdData.points.lat ==m.props.center.lat && markerdData.points.lng ==m.props.center.lng));
  //       if(m)
  //       m.props.radius = Math.sqrt(currOffice.empno) *  100
  //      // m.setMap(null);
  //     }
  //   }


  //   useEffect(() => {
  //      itemsRef.current = itemsRef.current.slice(0,(markers?.length||0));
  //   }, [markers]);


  const CenterControl = (controlDiv, map) => {
    // Set CSS for the control border.
    const controlUI = document.createElement("div");
    const abudhabi = { lat: 24.4211889, lng: 54.4313433 };
    controlUI.style.backgroundColor = "#fff";
    controlUI.style.border = "2px solid #fff";
    controlUI.style.borderRadius = "3px";
    controlUI.style.boxShadow = "0 2px 6px rgba(0,0,0,.3)";
    controlUI.style.cursor = "pointer";
    controlUI.style.marginTop = "8px";
    controlUI.style.marginBottom = "22px";
    controlUI.style.textAlign = "center";
    controlUI.title = "Click to recenter the map";
    controlDiv.appendChild(controlUI);

    // Set CSS for the control interior.
    const controlText = document.createElement("div");

    controlText.style.color = "rgb(25,25,25)";
    controlText.style.fontFamily = "Roboto,Arial,sans-serif";
    controlText.style.fontSize = "16px";
    controlText.style.lineHeight = "38px";
    controlText.style.paddingLeft = "5px";
    controlText.style.paddingRight = "5px";
    controlText.innerHTML = "Abu Dhabi";
    controlUI.appendChild(controlText);
    //Setup the click event listeners: simply set the map to Chicago.
    controlUI.addEventListener("click", () => {
      map.setCenter(abudhabi);
      map.setZoom(13)
    });
  }


  const LegendControl = (controlDiv, map) => {
    // Set CSS for the control border.
    const controlUI = document.createElement("div");
    const abudhabi = { lat: 24.4211889, lng: 54.4313433 };
    controlUI.style.backgroundColor = "#fff";
    controlUI.style.border = "2px solid #fff";
    controlUI.style.borderRadius = "3px";
    controlUI.style.boxShadow = "0 2px 6px rgba(0,0,0,.3)";
    controlUI.style.cursor = "pointer";
    controlUI.style.marginTop = "8px";
    controlUI.style.marginBottom = "22px";
    controlUI.style.textAlign = "center";
    controlUI.title = "Click to recenter the map";
    controlDiv.appendChild(controlUI);

    // Set CSS for the control interior.
    // const controlText = document.createElement("svg");
    // controlText.id = "my_dataviz";
    // controlText.height = 300;
    // controlText.width = 450;
    const controlText = document.createElement("div");
    controlText.style.color = "rgb(25,25,25)";
    controlText.style.fontFamily = "Roboto,Arial,sans-serif";
    controlText.style.fontSize = "16px";
    controlText.style.lineHeight = "38px";
    controlText.style.paddingLeft = "5px";
    controlText.style.paddingRight = "5px";
    controlText.innerHTML = `<svg width="249.28125" height="45.28" viewBox="0 0 191 45.28" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
  <defs>
      <pattern id="atlas-pattern-491d82dc-1db2-4d12-a4fd-7b6320056319" x="0" y="0" width="10" height="10" patternUnits="userSpaceOnUse">
          <rect x="0" y="0" width="10" height="10" fill="white"></rect>
          <rect x="0" y="0" width="5" height="5" fill="#ccc"></rect>
          <rect x="5" y="5" width="5" height="5" fill="#ccc"></rect>
      </pattern>

      <linearGradient id="atlas-gradient-491d82dc-1db2-4d12-a4fd-7b6320056319" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stop-color="royalblue"></stop><stop offset="25%" stop-color="cyan"></stop><stop offset="50%" stop-color="lime"></stop><stop offset="75%" stop-color="yellow"></stop><stop offset="100%" stop-color="red"></stop></linearGradient>
  </defs>

  <rect x="0" y="0" width="191" height="16" fill="url('#atlas-pattern-491d82dc-1db2-4d12-a4fd-7b6320056319')"></rect>
  <rect x="0" y="0" width="191" height="16" fill="url('#atlas-gradient-491d82dc-1db2-4d12-a4fd-7b6320056319')"></rect>

  <g style="stroke:#011c2c;stroke-width:2;"><line x1="0" y1="19" x2="191" y2="19"></line><line x1="1" y1="19" x2="1" y2="21"></line><line x1="95.5" y1="19" x2="95.5" y2="21"></line><line x1="190" y1="19" x2="190" y2="21"></line></g>

  <g style="fill:#011c2c;font-size:16px;font-family:'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif;text-align:center;text-anchor:middle;dominant-baseline:hanging;"><text x="1" y="24">low</text><text x="95.5" y="24">medium</text><text x="180" y="24">high(>300)</text></g>

</svg>`;
    controlUI.appendChild(controlText);

    const controlTextdiv = document.createElement("div");
    controlTextdiv.style.color = "rgb(25,25,25)";
    controlTextdiv.style.fontFamily = "Roboto,Arial,sans-serif";
    controlTextdiv.style.fontSize = "16px";
    controlTextdiv.style.lineHeight = "38px";
    controlTextdiv.style.paddingLeft = "5px";
    controlTextdiv.style.paddingRight = "5px";
    controlTextdiv.innerHTML = `No. of Employees`;
    controlUI.appendChild(controlTextdiv);

  }

  const onLoad = React.useCallback((map) => {

    setMapRef(map)
    window.employeeMap = map;
    sv = new window.google.maps.StreetViewService();
    // Create the DIV to hold the control and call the CenterControl()
    // constructor passing in this DIV.
    const centerControlDiv = document.createElement("div");

    CenterControl(centerControlDiv, map);
    map.controls[window.google.maps.ControlPosition.TOP_CENTER].push(centerControlDiv);

    const legendControlDiv = document.createElement("div");

    LegendControl(legendControlDiv, map);
    map.controls[window.google.maps.ControlPosition.LEFT_BOTTOM].push(legendControlDiv);

    //     let me ;
    //     function MyPane() {}
    // MyPane.prototype = new window.google.maps.GControl;
    // MyPane.prototype.initialize = function(map) {
    //     me = this;
    //   me.panel = document.createElement("div");
    //   me.panel.style.width = "150px";
    //   me.panel.style.height = "100px";
    //   me.panel.style.border = "1px solid gray";
    //   me.panel.style.background = "white";
    //   me.panel.innerHTML = "Hello World!";
    //   map.getContainer().appendChild(me.panel);
    //   return me.panel;
    // };

    // MyPane.prototype.getDefaultPosition = function() {
    //   return new window.google.maps.GControlPosition(
    //     google.maps.ControlPosition.TOP_RIGHT, new window.google.maps.GSize(10, 50));
    //       //Should be _ and not &#95;
    // };

    // MyPane.prototype.getPanel = function() {
    //   return me.panel;
    // }
    // map.addControl(new MyPane());

    // Handle the DOM ready event to create the StreetView panorama
    // as it can only be created once the DIV inside the infowindow is loaded in the DOM.

    // const trafficLayer = new window.google.maps.TrafficLayer();

    // trafficLayer.setMap(map);

    // const heatmap = new window.google.maps.visualization.HeatmapLayer({
    //   data: getPoints(),
    //   map: map,
    // });
    // Define the LatLng coordinates for the polygon's path.
    // NOTE: This uses cross-domain XHR, and may not work on older browsers.


    //sectors
    // map.data.loadGeoJson(
    // "/avatars/abudhabi2.json"
    // );
    // map.data.setStyle({
    //   fillColor: "green",
    //   strokeWeight: 5,
    // });
    // Define the LatLng coordinates for the polygon's path.
    // var triangleCoords = [{lng:  54.386418344999981,lat: 24.494321979000006},
    //   {lng:  54.386480448999976,lat: 24.494161885999972},
    //   {lng:  54.387052005999976,lat: 24.493164293999996},
    //   {lng:  54.387879616000021,lat: 24.491896449000023},
    //   {lng:  54.387887428999989,lat: 24.491888281000001},
    //   {lng:  54.388275576000012,lat: 24.492354395999996},
    //   {lng:  54.388367071000005,lat: 24.492476263000015},
    //   {lng:  54.388453115999994,lat: 24.492606066999997},
    //   {lng:  54.388530945000014,lat: 24.49274015200001},
    //   {lng:  54.388600311000005,lat: 24.492878061999988},{lng:  54.38866098699998,lat: 24.493019430999993},{lng:  54.388712904999977,lat: 24.493163627000001},
    //   {lng:  54.388755666000009,lat: 24.493310364000024},{lng:  54.388789356000018,lat: 24.493458938000003},{lng:  54.388813942000013,lat: 24.493611326000007},
    //   {lng:  54.389067888,lat: 24.49555409200002},{lng:  54.388897281000027,lat: 24.495544731999985},{lng:  54.388727443999983,lat: 24.495526268999981},
    //   {lng:  54.38855900599998,lat: 24.495498813999973},{lng:  54.388392705000001,lat: 24.495462459999999},{lng:  54.388228863999984,lat: 24.495417304},
    //   {lng:  54.388068209999972,lat: 24.495363538999982},{lng:  54.387911222000014,lat: 24.495301352000013},{lng:  54.387758476999977,lat: 24.495230945000003}
    //   ,{lng:  54.387610456000004,lat: 24.495152486999984},{lng:  54.387467633000028,lat: 24.495066366000003},{lng:  54.387330008999982,lat: 24.494972573999974}
    //   ,{lng:  54.387054772999988,lat: 24.494772993000026},{lng:  54.386415155999998,lat: 24.494330226999978},{lng:  54.386418344999981,lat: 24.494321979000006}];

    console.log(geoshap);
    //   var triangleCoords1 = geoshap.features.filter(f=>f.properties.DISTRICTID == "35" && f.properties.OBJECTID== 565).map(k=>k.geometry.coordinates.map(c=>c.map(n=>({lng: n[0],lat: n[1]})))[0])[0]
    //   var triangleCoords2 = geoshap.features.filter(f=>f.properties.DISTRICTID == "35"  && f.properties.OBJECTID== 127 ).map(k=>k.geometry.coordinates.map(c=>c.map(n=>({lng: n[0],lat: n[1]})))[0])[0]

    //   var triangleCoords =[triangleCoords1,triangleCoords2]
    //   //debugger;
    // // Construct the polygon.
    // var bermudaTriangle = new window.google.maps.Polygon({
    //   paths: [triangleCoords1,triangleCoords2 ],
    //   strokeColor: '#FFFFFF',
    //   strokeOpacity: 0.8,
    //   strokeWeight: 2,
    //   fillColor: '#FFFFFF',
    //   fillOpacity: 0.8
    // });
    // bermudaTriangle.setMap(map);


    // // Construct the polygon.
    // var bermudaTriangle2 = new window.google.maps.Polygon({
    //   paths: triangleCoords2,
    //   strokeColor: '#FFFFFF',
    //   strokeOpacity: 0.8,
    //   strokeWeight: 2,
    //   fillColor: '#FFFFFF',
    //   fillOpacity: 0.8
    // });
    // bermudaTriangle2.setMap(map);
    // Add a listener for the click event.

    const infoWindow = new window.google.maps.InfoWindow();

    function showArrays(event) {
      // Since this polygon has only one path, we can call getPath() to return the
      // MVCArray of LatLngs.
      const polygon = this;
      const vertices = polygon.getPath();
      let contentString =
        "<b>GOVERNMENT OFFICES & EMPLOYEES</b><br>" +
        "Clicked location: <br>" +
        event.latLng.lat() +
        "," +
        event.latLng.lng() +
        "<br>";

      // Iterate over the vertices.
      for (let i = 0; i < vertices.getLength(); i++) {
        const xy = vertices.getAt(i);

        contentString +=
          "<br>" + "Coordinate " + i + ":<br>" + xy.lat() + "," + xy.lng();
      }

      // Replace the info window's content and position.
      infoWindow.setContent(contentString);
      infoWindow.setPosition(event.latLng);
      infoWindow.open(map);
    }


  }, []);

  const onInfoDomReady = (infoLocation) => {

    // if(!sv)
    // sv =  new window.google.maps.StreetViewService();

    // sv?.getPanoramaByLocation({
    //   lat:mapRef.center.lat(),
    //   lng: mapRef.center.lng(),
    // }, 50, (data, status) => {

    //   if (status == window.google.maps.StreetViewStatus.OK) {



    //     if (!!panorama && !!panorama.setPano) {

    //       panorama.setPano(data.location.pano);
    //       panorama.setPov({
    //         heading: 270,
    //         pitch: 0,
    //         zoom: 1
    //       });
    //       panorama.setVisible(true);

    //     }
    //     setStreetviewvisible('block')
    //   } else {
    //     setStreetviewvisible('none')

    //     panorama.setVisible(false);
    //     // alert("Street View data not found for this location.");
    //   }
    // });

    // var pin = new window.google.maps.MVCObject();

    // panorama = new window.google.maps.StreetViewPanorama(infostreetview.current, {
    //   navigationControl: false,
    //   enableCloseButton: false,
    //   addressControl: false,
    //   linksControl: false,
    //   visible: true
    // });
    // panorama.bindTo("position", pin);

  };

  const onUnmount = React.useCallback((mapData) => {
  }, []);

  // const onZIndexChanged =  (mapData) => {
  //   var zoomLevel = mapRef?.getZoom();
  //   //debugger;
  //  // setzoomforradiusLevel(zoomforradiusLevel)
  //  //  resetZoom(zoomLevel)
  // } ;

  var myStyles = [
    { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
    { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
    { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
    {
      featureType: "administrative.locality",
      elementType: "labels.text.fill",
      stylers: [{ color: "#d59563" }],
    },
    {
      featureType: "poi",
      elementType: "labels.text.fill",
      stylers: [{ color: "#d59563" }],
    },
    {
      featureType: "poi.park",
      elementType: "geometry",
      stylers: [{ color: "#263c3f" }],
    },
    {
      featureType: "poi.park",
      elementType: "labels.text.fill",
      stylers: [{ color: "#6b9a76" }],
    },
    {
      featureType: "road",
      elementType: "geometry",
      stylers: [{ color: "#38414e" }],
    },
    {
      featureType: "road",
      elementType: "geometry.stroke",
      stylers: [{ color: "#212a37" }],
    },
    {
      featureType: "road",
      elementType: "labels.text.fill",
      stylers: [{ color: "#9ca5b3" }],
    },
    {
      featureType: "road.highway",
      elementType: "geometry",
      stylers: [{ color: "#746855" }],
    },
    {
      featureType: "road.highway",
      elementType: "geometry.stroke",
      stylers: [{ color: "#1f2835" }],
    },
    {
      featureType: "road.highway",
      elementType: "labels.text.fill",
      stylers: [{ color: "#f3d19c" }],
    },
    {
      featureType: "transit",
      elementType: "geometry",
      stylers: [{ color: "#2f3948" }],
    },
    {
      featureType: "transit.station",
      elementType: "labels.text.fill",
      stylers: [{ color: "#d59563" }],
    },
    {
      featureType: "water",
      elementType: "geometry",
      stylers: [{ color: "#17263c" }],
    },
    {
      featureType: "water",
      elementType: "labels.text.fill",
      stylers: [{ color: "#515c6d" }],
    },
    {
      featureType: "water",
      elementType: "labels.text.stroke",
      stylers: [{ color: "#17263c" }],
    },
    {
      featureType: "poi",
      elementType: "labels",
      stylers: [
        { visibility: "off" }
      ]
    }
  ];
  const styles = [
    {
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#212121"
        }
      ]
    },
    {
      "elementType": "labels.icon",
      "stylers": [
        {
          "visibility": "off"
        }
      ]
    },
    {
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#757575"
        }
      ]
    },
    {
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#212121"
        }
      ]
    },
    {
      "featureType": "administrative",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#757575"
        }
      ]
    },
    {
      "featureType": "administrative.country",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#9e9e9e"
        }
      ]
    },
    {
      "featureType": "administrative.land_parcel",
      "stylers": [
        {
          "visibility": "off"
        }
      ]
    },
    {
      "featureType": "administrative.locality",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#bdbdbd"
        }
      ]
    },
    {
      "featureType": "poi",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#757575"
        }
      ]
    },
    {
      "featureType": "poi.park",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#181818"
        }
      ]
    },
    {
      "featureType": "poi.park",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#616161"
        }
      ]
    },
    {
      "featureType": "poi.park",
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#1b1b1b"
        }
      ]
    },
    {
      "featureType": "road",
      "elementType": "geometry.fill",
      "stylers": [
        {
          "color": "#2c2c2c"
        }
      ]
    },
    {
      "featureType": "road",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#8a8a8a"
        }
      ]
    },
    {
      "featureType": "road.arterial",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#373737"
        }
      ]
    },
    {
      "featureType": "road.highway",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#3c3c3c"
        }
      ]
    },
    {
      "featureType": "road.highway.controlled_access",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#4e4e4e"
        }
      ]
    },
    {
      "featureType": "road.local",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#616161"
        }
      ]
    },
    {
      "featureType": "transit",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#757575"
        }
      ]
    },
    {
      "featureType": "water",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#000000"
        }
      ]
    },
    {
      "featureType": "water",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#3d3d3d"
        }
      ]
    }
  ];
  const onLoadHeat = heatmapLayer => {
    console.log('HeatmapLayer onLoad heatmapLayer: ', heatmapLayer)
  }

  const onUnmountHeat = heatmapLayer => {
    console.log('HeatmapLayer onUnmount heatmapLayer: ', heatmapLayer)
  }
  const perc2color = (perc, min, max) => {
    var base = (max - min);

    if (base == 0) { perc = 100; }
    else {
      perc = (perc - min) / base * 100;
    }
    var r, g, b = 0;

    if (perc < 50) {
      r = 255;
      g = Math.round(5.1 * perc);
    }
    else {
      g = 255;
      r = Math.round(510 - 5.10 * perc);
    }
    var h = g * 0x10000 + r * 0x100 + b * 0x1;

    return '#' + ('000000' + h.toString(16)).slice(-6);
  }


  const clearInfoWindow = () => setIntfoLocation(null);

  let cur = 0;
  const onMarkerClick = (e, yatchId) => {

    const { latLng } = e;
    setIntfoLocation(latLng);
    //setCurrentcenter(latLng);///
    //m.props.center
    // setZoom(15);
    //AL SHAMKHA 65
    //BANIYAS 61
    //KHALIFA CITY 26
    //MOHAMED BIN ZAYED CITY 48
    //debugger;
    if (!window.directionsDisplayArray) window.directionsDisplayArray = [];
    setEmployeeLocations([]);
    window.directionsDisplayArray.map((k) => {
      k.setMap(null);
    });
    setRouteResults([]);
    //debugger;
    geoshap.features.filter(f => (f.properties.DISTRICTID == "65" || f.properties.DISTRICTID == "61" || f.properties.DISTRICTID == "26" || f.properties.DISTRICTID == "48") && f.properties.MUNICIPALITYNAME == "ADM").map(k => ({ props: k.properties, cord: k.geometry.coordinates.map(c => c.map(n => ({ lng: n[0], lat: n[1] })))[0] })).map((coordprops, i) => {

      const coordinates = coordprops.cord;
      const employeespercentage = Math.floor(Math.random() * 100) + 10;
      const locationsprops = coordprops.props;
      var bermudaTriangle = new window.google.maps.Polygon({
        paths: coordinates,
        strokeColor: '#FFFFFF',
        strokeOpacity: 0.4,
        strokeWeight: 1,
        fillColor: perc2color(employeespercentage, 10, 100),
        fillOpacity: 0.25
      });

      bermudaTriangle.setMap(window.employeeMap);

      //instantiate directions service and directions renderer
      const directionsService = new window.google.maps.DirectionsService();

      //Getting the first coordinate in the array as the start/origin
      let start = { lat: latLng.lat(), lng: latLng.lng() };
      //Getting the last coordinate in the array as the end/destination
      let end = {
        lat: coordinates[coordinates.length - 1].lat,
        lng: coordinates[coordinates.length - 1].lng,
      };



      // directions requests

      let request = {
        origin: start,
        destination: end,
        travelMode: "DRIVING",
      };
      //show results in the directionsrenderer
      directionsService.route(request, function (result, status) {
        if (status == "OK") {
          window.directionsDisplayArray[cur] = new window.google.maps.DirectionsRenderer({
            polylineOptions: {
              strokeColor: "red"
            },
            suppressMarkers: true
          });
          //put directions renderer to render in the map
          window.directionsDisplayArray[cur].setMap(window.employeeMap);
          window.directionsDisplayArray[cur].setDirections(result);
          cur = cur + 1;

          let averageTravellingTime = 4159;
          let averagedistance = 83299;
          let noofemployee = 40926;

          if ([...routeResults, result]?.length > 0) {
            averageTravellingTime = 0;
            averagedistance = 0;
            noofemployee = routeResults?.length;

            [...routeResults, result]?.map((routeResultsdata, i) => {
              console.log('routeResultsdata.routes[0]?.legs[0]?.duration.value', routeResultsdata.routes[0]?.legs[0]?.duration.value);
              console.log('routeResultsdata.routes[0]?.legs[0]?.distance.value', routeResultsdata.routes[0]?.legs[0]?.distance.value);
              averageTravellingTime = averageTravellingTime + (routeResultsdata.routes[0]?.legs[0]?.duration.value / 60);
              averagedistance = averagedistance + (routeResultsdata.routes[0]?.legs[0]?.distance.value / 1000);

            });
            averageTravellingTime = (averageTravellingTime / [...routeResults, result]?.length);
            averagedistance = (averagedistance / [...routeResults, result]?.length);
          }
          setRouteResults(oldArray => [...oldArray, result]);


          proxylocationRountingresult(averageTravellingTime, averagedistance)
          setEmployeeLocations(oldArray => [...oldArray, {
            infoLocation: new window.google.maps.LatLng(coordinates[coordinates.length - 1].lat, coordinates[coordinates.length - 1].lng),
            locinfo: result,
            locationsprops,
            employeespercentage
          }]);

        }
      });



      // const infoWindow = new window.google.maps.InfoWindow();

      // function openinfo(point) {
      //   // Since this polygon has only one path, we can call getPath() to return the
      //   // MVCArray of LatLngs.
      //   const polygon = this;
      //   //const vertices = polygon.getPath();
      //   let contentString =
      //     "<b>% of Employees Working at </b><br>" +
      //     "Clicked location: <br>" +
      //     point.lat() +
      //     "," +
      //     point.lng() +
      //     "<br>";
      //   // Replace the info window's content and position.
      //   infoWindow.setContent(contentString);
      //   infoWindow.setPosition(point);
      //   infoWindow.open(window.employeeMap);
      // }
      // openinfo(new window.google.maps.LatLng(coordinates[coordinates.length - 1].lat,coordinates[coordinates.length - 1].lng));
      //bermudaTriangle.addListener("click", showArrays);

    });
    setZoom(12);



    //debugger;
    const yatch = officeLocations.find((data) => data._id === yatchId);
    if (totalrouteResults.length == 0) {
      settotalRouteResults(routeResults)
    }

    setRouteResults(totalrouteResults.filter(routeResultsdata => {

      const emp = (currentEmployeeLocations || []).find((empLoc) => (empLoc.lat == routeResultsdata.request.origin.location.lat() && empLoc.lng == routeResultsdata.request.origin.location.lng()));
      return emp?.businessgroupid == yatchId;

    }));
    // const directionServiceArrayloc  =   (currentEmployeeLocations || []).filter((empLoc)=>empLoc.businessgroupid == yatchId ).map(empLoc => {

    //    const   directionServiceOpts = {
    //     options: {
    //       destination: { lat: yatch.location.coordinates[1], lng: yatch.location.coordinates[0] },
    //       travelMode: 'DRIVING',
    //       origin: { lat: empLoc.lat, lng: empLoc.lng  },

    //     },
    //     callBackFunction: callBackOnLoc,

    //   }

    //   return directionServiceOpts;
    //  // return ({ lat: destiantion.lat, lng: destiantion.lng });
    // });
    // setDirectionServiceArray(directionServiceArrayloc);
    if (yatch) setSelectedOffice(yatch);

    if (!sv)
      sv = new window.google.maps.StreetViewService();
    //debugger;
    sv?.getPanoramaByLocation({
      lat: latLng.lat(),
      lng: latLng.lng(),
    }, 50, (data, status) => {
      //debugger;
      if (status == window.google.maps.StreetViewStatus.OK) {



        if (!!panorama && !!panorama.setPano) {

          panorama.setPano(data.location.pano);
          panorama.setPov({
            heading: 270,
            pitch: 0,
            zoom: 1
          });
          panorama.setVisible(true);

        }
        setStreetviewvisible('block')
      } else {
        setStreetviewvisible('none')

        panorama.setVisible(false);
        // alert("Street View data not found for this location.");
      }
    });

    var pin = new window.google.maps.MVCObject();

    panorama = new window.google.maps.StreetViewPanorama(infostreetview.current, {
      navigationControl: false,
      enableCloseButton: false,
      addressControl: false,
      linksControl: false,
      visible: true
    });
    panorama.bindTo("position", pin);

    onMarkerClickParent(yatch);

  };
  if (isLoaded) {
    if (type === 'PlacedAutoComplete') {
      return <AutoCompleteComponent error={error} register={register} withLatLng={withLatLng} handleAddress={handleAddress} />;
    }


    const iconSm = `<svg
id="Layer_1"
data-name="Layer 1"
xmlns="http://www.w3.org/2000/svg"
xmlns:xlink="http://www.w3.org/1999/xlink"
viewBox="0 0 100 120"
>
<defs>
  <style>
    .cls-1{fill:url(#linear-gradient)}
    .cls-2{fill:#fff;}
    .cls-3{fill:url(#linear-gradient-2);}
  </style>
  <linearGradient id="linear-gradient" x1="12" y1="3.01" x2="12" y2="20.59" gradientUnits="userSpaceOnUse">
    <stop offset="0" stop-color="#ff005c"/><stop offset="0.11" stop-color="#f6005e"/><stop offset="0.29" stop-color="#dc0063"/><stop offset="0.53" stop-color="#b3006b"/><stop offset="0.8" stop-color="#7a0076"/>
    <stop offset="1" stop-color="#4d007f"/></linearGradient><linearGradient id="linear-gradient-2" x1="12" y1="-0.09" x2="12" y2="25.12" gradientUnits="userSpaceOnUse">
    <stop offset="0" stop-color="#ff005c"/>
    <stop offset="0.17" stop-color="#e60061"/>
    <stop offset="0.54" stop-color="#a6006e"/>
    <stop offset="1" stop-color="#4d007f"/>
  </linearGradient>
</defs>
<title>Marker_01</title>
<path class="cls-1" d="M12,23.69C10.81,22.84,2.49,16.63,2.49,10a9.51,9.51,0,1,1,19,0C21.51,16.63,13.19,22.84,12,23.69Z"/>
<path class="cls-2" d="M12,.7A9.27,9.27,0,0,1,21.26,10c0,6.33-7.67,12.27-9.26,13.43C10.42,22.23,2.74,16.29,2.74,10A9.27,9.27,0,0,1,12,.7m0-.5A9.76,9.76,0,0,0,2.24,10C2.24,17.33,12,24,12,24s9.76-6.67,9.76-14A9.76,9.76,0,0,0,12,.2Z"/>
<circle class="cls-3" cx="12" cy="10" r="4.5"/>
<path class="cls-2" d="M12,6a4,4,0,1,1-4,4,4,4,0,0,1,4-4m0-1a5,5,0,1,0,5,5,5,5,0,0,0-5-5Z"/>
</svg>`;

    let averageTravellingTime = 4159;
    let averagedistance = 83299;
    let noofemployee = 40926;
    let noofoffices = officeLocations?.length || 0;
    if (routeResults?.length > 0) {
      averageTravellingTime = 0;
      averagedistance = 0;
      noofemployee = routeResults?.length;
      noofoffices = markers?.length;
      routeResults?.map((routeResultsdata, i) => {
        averageTravellingTime = averageTravellingTime + routeResultsdata.routes[0]?.legs[0]?.duration.value;
        averagedistance = averagedistance + routeResultsdata.routes[0]?.legs[0]?.distance.value;

      });
    }
    const gradient = [
      "rgba(0, 255, 255, 0)",
      "rgba(0, 255, 255, 1)",
      "rgba(0, 191, 255, 1)",
      "rgba(0, 127, 255, 1)",
      "rgba(0, 63, 255, 1)",
      "rgba(0, 0, 255, 1)",
      "rgba(0, 0, 223, 1)",
      "rgba(0, 0, 191, 1)",
      "rgba(0, 0, 159, 1)",
      "rgba(0, 0, 127, 1)",
      "rgba(63, 0, 91, 1)",
      "rgba(127, 0, 63, 1)",
      "rgba(191, 0, 31, 1)",
      "rgba(255, 0, 0, 1)"
    ];
    // mapId: "fcc5a7955fc5718e",
    return (<>
      <CRow>
        <CCol xs>
          <div className="map-large">
            <GoogleMap
              mapContainerStyle={containerStyle}
              center={currentcenter}
              zoom={currentzoom || 9}
              options={{ styles }}
              onLoad={onLoad}
              onUnmount={onUnmount}
            // onZoomChanged ={onZIndexChanged}
            >
              {markers?.map(((markerdData, i) => {


                const icon = {
                  size: new window.google.maps.Size(markerdData.empno * 4, markerdData.empno * 4),
                  origin: new window.google.maps.Point(0, 0),
                  anchor: new window.google.maps.Point(16, 32)
                };
                const iconSm2 = `
<svg
id="Layer_1"
data-name="Layer 1"
xmlns="http://www.w3.org/2000/svg"
xmlns:xlink="http://www.w3.org/1999/xlink"
viewBox="0 0 ${markerdData.empno} ${markerdData.empno}"
>

<title>Marker_01</title>
 <circle cx="${markerdData.empno / 8}" cy="${markerdData.empno / 8}" r="${markerdData.empno / 8}" fill="red"/>
</svg> `;
                //  icon.url = 'data:image/svg+xml;charset=UTF-8;base64,' + btoa(`<svg width="160" height="160"><circle cx="80" cy="80" r="80" fill="red"/></svg>`);
                icon.url = 'data:image/svg+xml;charset=UTF-8;base64,' + btoa(iconSm2);

                const svgMarker = {
                  path: "M10.453 14.016l6.563-6.609-1.406-1.406-5.156 5.203-2.063-2.109-1.406 1.406zM12 2.016q2.906 0 4.945 2.039t2.039 4.945q0 1.453-0.727 3.328t-1.758 3.516-2.039 3.070-1.711 2.273l-0.75 0.797q-0.281-0.328-0.75-0.867t-1.688-2.156-2.133-3.141-1.664-3.445-0.75-3.375q0-2.906 2.039-4.945t4.945-2.039z",
                  fillColor: "blue",
                  fillOpacity: 0.6,
                  strokeWeight: 0,
                  rotation: 0,
                  scale: markerdData.empno / 10,

                };
                const options = {
                  strokeColor: '#FF0000',
                  strokeOpacity: 0.8,
                  strokeWeight: 0,
                  fillColor: '#FF0000',
                  fillOpacity: 0.85,

                  draggable: true,
                  editable: false,
                  visible: true,

                  zIndex: 1
                }
                const circlecolor = perc2color(parseInt(markerdData.empno) > 890 ? 890 : parseInt(markerdData.empno), 0, 300)

                const handleDragEnd = (e, draggedOffice) => {
                  console.log('test grow >>>', e, draggedOffice, markers)
                  const { latLng } = e;
                  const lat = latLng.lat();
                  const lng = latLng.lng();
                  const newOfficeLocData = {
                    ...draggedOffice,
                    points: {
                      lat,
                      lng,
                    }
                  };
                  const officeLocHistory = {
                    newLoc: {
                      ...newOfficeLocData
                    },
                    oldLoc: {
                      ...draggedOffice
                    }
                  }

                  Object.entries(officeLocHistory).map(([keyName, data]) => {

                    const { points: { lat, lng }, _id } = data;

                    const directionsService = new window.google.maps.DirectionsService();

                    let start = { lat: (lat + 1), lng: (lng + 1) };
                    //Getting the last coordinate in the array as the end/destination
                    let end = {
                      lat,
                      lng
                    };

                    let request = {
                      origin: start,
                      destination: end,
                      travelMode: "DRIVING",
                    };

                    directionsService.route(request, function (result, status) {
                      if (status == "OK") {
                        setDragedLoctions((currentData) => {
                          console.log("result got >>>", result, _id, keyName, currentData)
                          const newState = currentData?.filter(officeLoc => officeLoc?.oldLoc?._id !== _id);
                          const selected = currentData?.find(officeLoc => officeLoc?.oldLoc?._id === _id) || {};
                          return [...newState, { ...selected, [keyName]: { ...data, route: result } }]
                        })
                      }
                    });

                  })



                  // directions requests

                  // setDragedLoctions((currentHistory) => {
                  //   const newState = currentHistory.filter(officeLoc => officeLoc.oldLoc._id !== newOfficeLocData._id);
                  //   return [...newState, officeLocHistory]
                  // })
                  if (withLatLng) withLatLng({ lat, lng })
                }

                return (
                  <>

                    <Circle
                      strokeColor={"#FF0000"}
                      //ref={el => itemsRef.current[i] = el}
                      strokeOpacity={0.8}
                      strokeWeight={0}
                      fillColor={"#FF0000"}
                      fillOpacity={0.65}
                      draggable={true}
                      onDragEnd={(e) => handleDragEnd(e, markerdData)}
                      // onMouseOver={(e) => onMarkerClick(e, markerdData._id)}
                      onClick={(e) => onMarkerClick(e, markerdData._id)}
                      key={markerdData._id}
                      center={markerdData.points}
                      radius={Math.sqrt(markerdData.empno) * 10}
                      //     icon={()=>(`<svg width="${markerdData.empno *2}" height="${markerdData.empno *2}"> <circle cx="${markerdData.empno}" cy="${markerdData.empno}" r="${markerdData.empno}" fill="red"/>  </svg>`)}
                      //  icon={svgMarker}
                      //  label =  {markerdData.empno}
                      // animation={2}
                      // title={'title'}
                      // options={{...options, fillColor:parseInt(markerdData.empno)  >300? "#FF0000"  : parseInt(markerdData.empno)>100?"#0000FF":"#00FF00" ,fillOpacity: parseInt(markerdData.empno) <40 ? 0.40: parseInt(markerdData.empno) <100? parseInt(markerdData.empno)/100 : parseInt(markerdData.empno)/1000  }}
                      options={{ ...options, fillColor: circlecolor }}
                      optimized={false}

                    />
                  </>
                )
                //       <Marker
                //       draggable
                //       onDragEnd={dragChanged}
                //       ref={el => itemsRef.current[i] = el}
                //       onClick={(e) => onMarkerClick(e, markerdData._id)}
                //       key={markerdData._id}
                //       position={markerdData.points}
                //    //     icon={()=>(`<svg width="${markerdData.empno *2}" height="${markerdData.empno *2}"> <circle cx="${markerdData.empno}" cy="${markerdData.empno}" r="${markerdData.empno}" fill="red"/>  </svg>`)}
                //  //  icon={svgMarker}
                //       label =  {markerdData.empno}
                //      // animation={2}
                //      // title={'title'}

                //       optimized= {false}

                //     />
                return (<Circle
                  draggable
                  onDragEnd={handleDragEnd}
                  strokeColor={"#FF0000"}
                  strokeOpacity={0.8}
                  strokeWeight={2}
                  fillColor={"#FF0000"}
                  fillOpacity={0.35}

                  onClick={(e) => onMarkerClick(e, markerdData._id)}
                  key={markerdData._id}
                  center={markerdData.points}
                  radius={Math.sqrt(markerdData.empno) * 100}
                  //     icon={()=>(`<svg width="${markerdData.empno *2}" height="${markerdData.empno *2}"> <circle cx="${markerdData.empno}" cy="${markerdData.empno}" r="${markerdData.empno}" fill="red"/>  </svg>`)}
                  //  icon={svgMarker}
                  //  label =  {markerdData.empno}
                  // animation={2}
                  // title={'title'}

                  optimized={false}

                />)


              }))}

              <HeatmapLayer
                gradient={gradient}
                opacity={1}
                data={markers?.map((markerdData, i) => {
                  return new window.google.maps.LatLng(markerdData.points.lat, markerdData.points.lng)
                })}
                options={{ radius: 20 }}
              />


              {/*
{ selectedOffice && directionServiceArray?.map((directionServicedata,i) => {

 return (<DirectionsService
  key={'DirectionsService' + i}
   options={directionServicedata.options}
            callback={directionServicedata.callBackFunction}
          />);
})}

       {selectedOffice? routeResults?.map((routeResultsdata,i) => {

          return (<DirectionsRenderer
            key={'DirectionsRenderer' + i}
            directions={routeResultsdata}
          />);
        }):null} */}


              {infoLocation ? (
                <InfoWindow position={infoLocation} onDomReady={onInfoDomReady} onCloseClick={clearInfoWindow}>
                  {selectedOffice ? (
                    <div className="mapYatchWrapper">
                      <OfficeCard officedata={selectedOffice} />
                      <div ref={infostreetview} style={{ width: '100%', height: '200px', display: streetviewvisible }} > </div>
                    </div>
                  ) : (
                    <div>text</div>
                  )}
                </InfoWindow>
              ) : null}
              {employeeLocations?.map((emploc, i) => {
                return (
                  <InfoWindow key={i} position={emploc.infoLocation} onDomReady={onInfoDomReady} onCloseClick={clearInfoWindow}>
                    {selectedOffice ? (
                      <div className="mapYatchWrapper">
                        <ProxyLocations officedata={selectedOffice} infoLocation={emploc.locinfo} employeespercentage={emploc.employeespercentage} locationsprops={emploc.locationsprops} />
                      </div>
                    ) : (
                      <div>text</div>
                    )}
                  </InfoWindow>
                )
              })}

              {/* Child components, such as markers, info windows, etc. */}
              <></>
            </GoogleMap>


          </div>
        </CCol>
      </CRow>

      {routeResults?.length > 0 ?
        <CRow>
          <CCol xs>

            <CTable hover responsive align="middle" className="mb-0 border">
              <CTableHead color="light">
                <CTableRow>
                  <CTableHeaderCell className="text-center">
                    <CIcon name="cil-location-pin" />
                  </CTableHeaderCell>
                  <CTableHeaderCell>Office Name</CTableHeaderCell>


                  <CTableHeaderCell>Proxy Address</CTableHeaderCell>
                  <CTableHeaderCell>No. of Employees</CTableHeaderCell>
                </CTableRow>
              </CTableHead>
              <CTableBody>
                {routeResults?.map((routeResultsdata, i) => {
                  console.log('routeResultsdata', routeResultsdata);

                  const emp = (currentEmployeeLocations || []).find((empLoc) => (empLoc.lat == routeResultsdata.request.origin.location.lat() && empLoc.lng == routeResultsdata.request.origin.location.lng()));

                  return (<CTableRow key={'routeResultsRow' + i}>
                    <CTableDataCell className="text-center">
                      <CIcon name="cil-location-pin" />
                    </CTableDataCell>
                    <CTableDataCell>
                      <div>{selectedOffice?.businessgroupname}</div>
                      <div className="small text-medium-emphasis">
                        <span>{routeResultsdata.routes[0]?.legs[0]?.start_address} </span>
                      </div>
                    </CTableDataCell>


                    <CTableDataCell>
                      <div className="small text-medium-emphasis"> {routeResultsdata.routes[0]?.legs[0]?.end_address}</div>

                      <strong>   <small className="text-medium-emphasis">
                        {'Duration: '}
                      </small> {routeResultsdata.routes[0]?.legs[0]?.duration.text} </strong>
                      <strong>   <small className="text-medium-emphasis">
                        {'Distance: '}
                      </small> {routeResultsdata.routes[0]?.legs[0]?.distance.text} </strong>

                    </CTableDataCell>

                    <CTableDataCell>
                      <div className="small text-medium-emphasis"> {Math.floor(Math.random() * 500) + 100}</div>


                      <CProgress thin color="success" value={50} />
                    </CTableDataCell>
                  </CTableRow>);
                })}



              </CTableBody>
            </CTable>
          </CCol>
        </CRow> : null}
    </>

    );
  } return <></>;
};

MapComponent.propTypes = {
  withLatLng: PropTypes.func,
  type: "PlacedAutoComplete",
  center: PropTypes.object,
  markers: PropTypes.array,
  handleAddress: PropTypes.func,
  register: PropTypes.object,
  error: PropTypes.string,
  directionServiceOpts: PropTypes.object,
  directionCallback: PropTypes.func,
}

AutoCompleteComponent.propTypes = {
  withLatLng: MapComponent.propTypes['withLatLng'],
  handleAddress: MapComponent.propTypes['handleAddress'],
  register: MapComponent.propTypes['register'],
  error: MapComponent.propTypes['error'],
}


export default memo(MapComponent);


