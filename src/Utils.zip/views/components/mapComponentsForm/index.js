import PropTypes from 'prop-types'
import React, {
  useState, useRef,
  memo,
} from 'react';
import {
  GoogleMap, useJsApiLoader, Marker, Autocomplete,
} from '@react-google-maps/api';
import { CFormControl } from '@coreui/react';


const centerProp = {
  lat: 20.5937,
  lng: 78.9629,
};

const libraries = ['places'];


export const AutoCompleteComponent = ({ withLatLng, handleAddress, register = {}, error }) => {
  const autoCompltedRef = useRef(null);

  const onLoad = (something) => {
    console.log('something on Load', something);
    autoCompltedRef.current = something;
  };

  const onPlaceChanged = (e) => {
    if (autoCompltedRef.current) {
      const place = autoCompltedRef.current.getPlace();
      console.log("place got >>", place)
      if (place.geometry && place.geometry.location) {
        const lat = place.geometry.location.lat();
        const lng = place.geometry.location.lng();
        console.log({ lat, lng })
        if (withLatLng) withLatLng({ lat, lng });
        const { address_components } = place;
        if (handleAddress) handleAddress(address_components)
      }
    } else {
      console.log('Autocomplete is not loaded yet!');
    }
  };

  return (
    <Autocomplete
      onLoad={onLoad}
      onPlaceChanged={onPlaceChanged}
    // fields={['geometry']}
    >
      <CFormControl
        className={error ? "error-input" : ""}
        {...register}
        placeholder="SEARCH PLACE"
        type='text' />
    </Autocomplete>
  );
};


const MapComponent = ({
  type, withLatLng, center = centerProp, markers, handleAddress, register, error
}) => {
  const containerStyle = {
    width: '100%',
    height: '100%',
  };

  const [infoLocation, setIntfoLocation] = useState(null);
  const [selectedYatch, setYatch] = useState(null);

  const mapid = ["fcc5a7955fc5718e"];
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: 'AIzaSyDOqjoKY4YFUV3uS23oYocDSp8Rv36yhmQ',
    libraries,
    mapIds:mapid
  });
 
  const onUnmount = React.useCallback((mapData) => {
  }, []);

  const dragChanged = (e) => {
    const { latLng } = e;
    const lat = latLng.lat();
    const lng = latLng.lng();
    if (withLatLng) withLatLng({ lat, lng })
  };


  if (isLoaded) {
    if (type === 'PlacedAutoComplete') {
      return <AutoCompleteComponent error={error} register={register} withLatLng={withLatLng} handleAddress={handleAddress} />;
    }
    return (
      <div className="map-wrapper">
        <GoogleMap
          mapContainerStyle={containerStyle}
          center={center}
          options={{ mapId: "fcc5a7955fc5718e" }}
          zoom={9}
          onUnmount={onUnmount}
        >
          {markers?.map(((markerdData) => (
            <Marker
              draggable
              onDragEnd={dragChanged}
              key={markerdData._id}
              position={markerdData.points}
            />
          )))}
          {/* Child components, such as markers, info windows, etc. */}
          <></>
        </GoogleMap>
      </div>
    );
  } return <></>;
};

MapComponent.propTypes = {
  withLatLng: PropTypes.func,
  type: "PlacedAutoComplete",
  center: PropTypes.object,
  markers: PropTypes.array,
  handleAddress: PropTypes.func,
  register: PropTypes.object,
  error: PropTypes.string,
}

AutoCompleteComponent.propTypes = {
  withLatLng: MapComponent.propTypes['withLatLng'],
  handleAddress: MapComponent.propTypes['handleAddress'],
  register: MapComponent.propTypes['register'],
  error: MapComponent.propTypes['error'],
}


export default memo(MapComponent);


