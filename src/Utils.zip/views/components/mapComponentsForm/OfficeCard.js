import React, { useCallback } from 'react'
import PropTypes from 'prop-types'
 
import gql from 'graphql-tag';
import { useMutation } from '@apollo/react-hooks';
import {
  CCard,
  CCardBody,
  CCardHeader, 
  CImage,
  CButton,
    
  CCardFooter,
  CCardGroup, 
  CCardImage,
  CCardLink,
  CCardSubtitle,
  CCardText,
  CCardTitle,
  CListGroup,
  CListGroupItem,
  CNav,
  CNavItem,
  CNavLink,
  CCol,
  CRow,
} from '@coreui/react'; 
const OfficeCard  = ({  officedata }) => {
   return ( 
        <CCard className="mb-4">
          <CCardHeader>
            <strong>{officedata?.businessgroupname}</strong>
          
          
          </CCardHeader>
          <CCardBody style={{justifyContent: 'center',  alignItems: 'center', display: 'flex', flexDirection: 'column'}} >
          <p className="text-medium-emphasis small">
          <small>Location:</small> <strong> <b>{officedata?.locationname}</b></strong> 
             
                </p>
                <p className="text-medium-emphasis small">
                <small> Number Of Employees:</small> <strong> <b> {officedata?.numberofemployees}</b></strong>
            
                </p>

          <CImage
                width="149px"
                src={officedata?.picture[0]?.url}
                className="d-inline-block align-top"
                alt="CoreuiVue"
              />
          
      
          </CCardBody>
        </CCard>
     
  );
}

OfficeCard.propTypes = {
  onCreate: PropTypes.func,
  officedata: PropTypes.array,
}
export default OfficeCard;
