import React, { useCallback, useMemo, useState } from 'react'
import PropTypes from 'prop-types'
import gql from 'graphql-tag';
import { useMutation,useQuery } from '@apollo/react-hooks';
import { CFormLabel, CRow } from '@coreui/react';
import constant from '../../../../constant'
import FileUploaderInput from '../../fileUploader';
import { useDropzone } from 'react-dropzone';
import XLSX from 'xlsx';
import {
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CForm, CButton
} from '@coreui/react';
import { DESTINATION_QUERY } from './employeeHome' 
import { Controller, FormProvider, useForm } from 'react-hook-form'
import RenderFormFields from '../../../../components/FormWrapper/RenderFormFields';
import MapComponents from '../../mapComponentsForm';
 
const DESTINATION_MUTATION = gql`
mutation EmployeeHomeCreateOneMutation($employeeHomeCreateOneRecord: CreateOneEmployeeHomeInput!) {
  employeeHomeCreateOne(record: $employeeHomeCreateOneRecord) {
    record { 
      businessgroupname
      employename
      locationid
      locationname 
      businessgroupid
      gender
      maritalstatus
      nationality
      personid
      persontype
      city
      officelat
      officelng
    }
  }
}
  `;  
  export const YACH_TYPE_QUERY = gql`
  {
    employeeOfficeMany {
      businessgroupname
      locationname 
      _id
    }
  }
`

const baseStyle = {
  flex: 1,
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  padding: '20px',
  borderWidth: 2,
  borderRadius: 2,
  borderColor: '#eeeeee',
  borderStyle: 'dashed',
  backgroundColor: '#fafafa',
  color: '#bdbdbd',
  outline: 'none',
  transition: 'border .24s ease-in-out',
  width: '300px'
};

const activeStyle = {
  borderColor: '#2196f3'
};

const acceptStyle = {
  borderColor: '#00e676'
};

const rejectStyle = {
  borderColor: '#ff1744'
};
const CreateYachtType = ({ onCreate }) => {
  const [YachtTypeMutation, { data }] = useMutation(DESTINATION_MUTATION, {
    refetchQueries: [
      { query: DESTINATION_QUERY, variables: {} }
    ]
  });

  const { loading: typeLoading, error: typeError, data: typeData } = useQuery(YACH_TYPE_QUERY)

  const [selectedLatLng, setLatLang] = useState(null)
  const [serverimgUrl, setServerImgUrl] = useState(null);
const employeeOfficemethords = useForm();
  const { register, getValues, handleSubmit, reset, setValue, watch, formState: { errors }, } =employeeOfficemethords;
  // typename
  //   description
  const onSubmit = (values) => {
    const {  businessgroupname,businessgroupid, locationid,locationname,employename } = values;
    console.log("checker >>> businessgroupname", businessgroupname);
    console.log("checker >>> locationname", locationname);
    console.log("checker >>> employename", employename);
    console.log("checker >>> locationid", locationid);
    console.log("checker >>> businessgroupid", businessgroupid);
    // businessgroupname
    // employename
    // locationid
    // locationname 

    console.log("lat lng >>>", selectedLatLng)
    
    // gender
    // maritalstatus
    // nationality
    // personid
    // persontype
    // city  
    // officelat 
    // officelng
    YachtTypeMutation({
      variables: {
        "employeeHomeCreateOneRecord": {
          "businessgroupname": businessgroupname,
          "businessgroupid": businessgroupid,
          "locationname": locationname,
          "employename": employename, 
          "locationid":locationid,
          location: {
            type: 'Point',
            coordinates: [selectedLatLng.lng, selectedLatLng.lat],
          },
          "picture": {
            "url": serverimgUrl,
            "displayorder": 1,
            "description": businessgroupname + locationname ,
            "title": businessgroupname,
            "pictureid": new Date().getUTCMilliseconds().toString()
          } 
         }
      }
    });
    onCreate();
    // console.log("checker >>>", e);
  };
  const yatchTypeOptions = useMemo(() => {
    if (typeData) {
      const { employeeOfficeMany } = typeData
      console.log('type data >>', employeeOfficeMany)
      return [...employeeOfficeMany.map(e=>{return {...e, typename: e.businessgroupname +  ' - ' + e.locationname}})]
    }
    return []
  }, [typeData])

  const memorizedOptions = useMemo(
    () => ({
      yatchTypeOptions,
      
    }),
    [yatchTypeOptions ],
  )

  const fieldsToRender = useMemo(() => ([
    { type: 'text', label: 'Business Group  Name', id: 'businessgroupname', name: 'businessgroupname', helpText: 'Business Group', colClass: "col-sm-4 col-4", },
    { type: 'text', label: 'Location Name', id: 'locationname', name: 'locationname', helpText: 'locationname', colClass: "col-sm-4 col-4", },
    { type: 'text', label: 'Employee Name', id: 'employename', name: 'employename', helpText: 'employename', colClass: "col-sm-4 col-4", },
     { type: 'text', label: 'Location ID', id: 'locationid', name: 'locationid', helpText: 'Location ID', colClass: "col-sm-4 col-4", },
    {
      type: 'select',
      name: 'businessgroupid',
      id: 'businessgroupid',
      placeholder: 'Select Office',
      label: 'Government Office',
      valueKey: '_id',
      labelKey: 'typename',
      colClass: 'col-sm-6 col-4',
      dynamicOptionKey: 'yatchTypeOptions',
      validation: {
        required: 'Government Office is required',
      },
    }
  ]), [])

  const country = watch('country');
  const employeeOffice = watch('country');
  const city = watch('country');

  const handleAddress = (addressData) => {
    console.log(addressData)
    const countryEntry = addressData.find(addArray => addArray?.types?.includes("country"))
    const cityEntry = addressData.find(addArray => addArray?.types?.includes("administrative_area_level_2"))
    const employeeOfficeEntry = addressData.find(addArray => addArray?.types?.includes("locality"))
    setValue('country', countryEntry ? countryEntry['long_name'] : "")
    setValue('city', cityEntry ? cityEntry['long_name'] : "")
    setValue('employeeOfficeName', employeeOfficeEntry ? employeeOfficeEntry['long_name'] : "")
  }


  
  const uploadFiles = Type => {
 
    acceptedFiles.forEach(file => {
      const reader = new FileReader();
      // eslint-disable-next-line
      const rABS = !!reader.readAsBinaryString;

      reader.onload = async e => {

        const bstr = e.target.result;
        const workbook = XLSX.read(bstr, { type: rABS ? 'binary' : 'array' });
        // eslint-disable-next-line
        const sheet_name_list = workbook.SheetNames[0];
        const jsonFromExcel = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list]);
        // eslint-disable-next-line
      console.log(jsonFromExcel);
      //   {
      //     "": "Female",
      //     "": "ADIO",
      //     "": "ADIO - Abu Dhabi Investment Office",
      //     "": 24.50023699999999,
      //     "": 54.388372,
      //     "": "Single",
      //     "": "United Arab Emirates",
      //     "": 1534473,
      //     "": "Employee",
      //     "": "Abu Dhabi"
      	

      // }
//.filter(d=>d.Latitude==24.50023699999999)
      jsonFromExcel.map((off,i)=>{

        // 
    // 
    // 
    // 
    // 
    // city  
    //  
    // officelng
   // if(i==0)
    YachtTypeMutation({
      variables: {
        "employeeHomeCreateOneRecord": {
          "businessgroupname": off["BUSINESS_GROUP_NAME"], 
          "businessgroupid":  (off["businessgroupid"] ||"0").toString(),
          "locationname": (off["Employee_ADDRESS_LINE_1"] + " " +  off["Employee_ADDRESS_LINE_2"] || "").toString(),  
          "employename": (off["FULL_NAME"] ||"0").toString(), 
          "locationid": (off["businessgroupid"] ||"0").toString(),
          "gender": (off["Gender"] ||"0").toString(),
          "maritalstatus": (off["MARITAL_STATUS"] ||"0").toString(),
          "nationality": (off["NATIONALITY"] ||"0").toString(),
          "personid": (off["PERSON_ID"] ||"0").toString(),
          "persontype": (off["PERSON_TYPE"] ||"0").toString(),
          "city": (off["CITY"] ||"0").toString(),
          "officelat":  off["Latitude"]   ,
          "officelng": off["Longitude"] 
         }
      }
    });


      })
       

      };
      if (rABS) { reader.readAsBinaryString(file); }
      else { reader.readAsArrayBuffer(file); }
    });
  };

  
  
  const {
    acceptedFiles,
    getRootProps,
    getInputProps,
    isDragActive,
    isDragAccept,
    isDragReject
  } = useDropzone({ accept: '.csv, .xlsx, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel' });

  const files = acceptedFiles.map(file => (
    <li key={file.path}>
      {file.path}
        - {file.size}
        bytes
    </li>
  ));


  const style = useMemo(() => ({
    ...baseStyle,
    ...(isDragActive ? activeStyle : {}),
    ...(isDragAccept ? acceptStyle : {}),
    ...(isDragReject ? rejectStyle : {})
  }), [
    isDragActive,
    isDragReject,
    isDragAccept
  ]);
  return (
    <CRow>

      <CCol xs={12}>
        <CCard className="mb-4">
          <CCardHeader>
            <strong>Business Group</strong>
          </CCardHeader>
          <CCardBody>
            <p className="text-medium-emphasis small">
              New Business Group
            </p>
            <CForm
              onSubmit={handleSubmit((e) => {
                onSubmit(getValues());
                reset(null);
              })}
            >
                <FormProvider {...employeeOfficemethords}>
              <CCol className={'mb-3'} xs={6}>
                <MapComponents
                  type='PlacedAutoComplete'
                  withLatLng={setLatLang}
                  handleAddress={handleAddress}
                />
              </CCol>
              <RenderFormFields
                 errors={errors}
                fields={fieldsToRender}
                register={register}
                options={memorizedOptions}
              />
              <CCol className="my-2" xs={6}>
                <MapComponents
                  markers={[{ points: selectedLatLng }]}
                  center={selectedLatLng || undefined}
                />
              </CCol>
              <>
                <FileUploaderInput
                  setResponseUrl={(data) => setServerImgUrl(data[0])}
                  Label="Picture"
                />
              </>
              </FormProvider>
              <CButton type="submit" color="primary">
                Submit
              </CButton>
            </CForm>
            <div>File Upload
          <div className={"newUser"}{...getRootProps({ style })}>
            <input {...getInputProps()} />
            <p>Drag and drop some files here, or click to select files</p>
          </div>
          {files.length > 0 && <React.Fragment>
            <div>
              <h4>Files</h4>
              <ul>{files}</ul>
            </div>
            <button className="saveButton"
              onClick={() => uploadFiles('SMS')}>Upload Employees</button>
           
          </React.Fragment>}</div>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  )
}

CreateYachtType.propTypes = {
  onCreate: PropTypes.func,
}
export default CreateYachtType;
