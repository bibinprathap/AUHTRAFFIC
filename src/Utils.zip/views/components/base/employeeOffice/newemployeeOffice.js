import React, { useCallback, useMemo, useState } from 'react'
import PropTypes from 'prop-types'
import gql from 'graphql-tag';
import { useMutation } from '@apollo/react-hooks';
import { CFormLabel, CRow } from '@coreui/react';
import constant from '../../../../constant'
import FileUploaderInput from '../../fileUploader';
import {
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CForm, CButton
} from '@coreui/react';
import { DESTINATION_QUERY } from './employeeOffice' 
import { Controller, FormProvider, useForm } from 'react-hook-form'
import RenderFormFields from '../../../../components/FormWrapper/RenderFormFields';
import MapComponents from '../../mapComponentsForm';
import officesdata from './officesdata'
const DESTINATION_MUTATION = gql`
mutation EmployeeOfficeCreateOneMutation($employeeOfficeCreateOneRecord: CreateOneEmployeeOfficeInput!) {
  employeeOfficeCreateOne(record: $employeeOfficeCreateOneRecord) {
    record { 
      businessgroupname
      businessgroupid
      locationid
      locationname
      numberofemployees
      malecount
      femalecount
      nationalcount
      nonnationalcount
      city
      singlecount
      marriedcount
      employeecount
      directhirecount
      permenentcount
      Regularcount  
      location {
        type
        coordinates
      }
    }
  }
}
  `; 

  


const CreateYachtType = ({ onCreate }) => {
  const [YachtTypeMutation, { data }] = useMutation(DESTINATION_MUTATION, {
    refetchQueries: [
      { query: DESTINATION_QUERY, variables: {} }
    ]
  });

  const [selectedLatLng, setLatLang] = useState(null)
  const [serverimgUrl, setServerImgUrl] = useState(null);
const employeeOfficemethords = useForm();
  const { register, getValues, handleSubmit, reset, setValue, watch } =employeeOfficemethords;
  // typename
  //   description
  const onSubmit = (values) => {
    const {  businessgroupname,businessgroupid, locationid,locationname,numberofemployees,malecount,femalecount,nationalcount,nonnationalcount,city,singlecount,marriedcount,employeecount,directhirecount,permenentcount ,Regularcount} = values;
    console.log("checker >>> employeeOfficeName", businessgroupname);
    console.log("checker >>> locationname", locationname);
    console.log("checker >>> locationname", numberofemployees);

    // malecount
    // femalecount
    // nationalcount
    // nonnationalcount
    // city
    // singlecount
    // marriedcount
    // employeecount
    // directhirecount
    // permenentcount
    // Regularcount  

    console.log("lat lng >>>", selectedLatLng);
    //filter(d=>d.Latitude==24.4299922).
    officesdata.map((off)=>{


      // "businessgroupname": "ADEK - Department of Education and Knowledge",
      // "city": null,
      // "Latitude": 24.4299922,
      // "Longitude": 54.4643367,
      // "locationname": "Department of Education and Knowledge Abu Dhabi Region Offices",
      // "numberofemployees": 6528,
      // "malecount": 1962,
      // "femalecount": 4566,
      // "nationalcount": 3566,
      // "nonnationalcount": 2962,
      // "singlecount": 1213,
      // "marriedcount": 5315,
      // "permenentcount": 0,
      // "employeecount": 6368,
      // "directhirecount": 0,
      // "RegularcountP": 0

      YachtTypeMutation({ 
         variables: {
          "employeeOfficeCreateOneRecord": {
            "businessgroupname": off["businessgroupname"],
            "locationname": (off["locationname"] || "0").toString(),
            "numberofemployees": (off["numberofemployees"] ||"0").toString(),
            "businessgroupid":(off["businessgroupid"] ||"0").toString(),
            "locationid":off["locationid"],
            "malecount":(off["malecount"]  || "0").toString(),
            "femalecount":(off["femalecount"]  || "0").toString(),
            "nationalcount":(off["nationalcount"]  || "0").toString(),
            "nonnationalcount":(off["nonnationalcount"]  || "0").toString(),
            "city":off["city"] || 'Abu Dhabi ',
            "singlecount":(off["singlecount"]  || "0").toString(),
            "marriedcount":(off["marriedcount"]   || "0").toString(),
            "employeecount":(off["employeecount"]   || "0").toString(),
            "directhirecount":(off["directhirecount"]  || "0").toString(),
            "permenentcount" :(off["permenentcount"]   || "0").toString(),
            "Regularcount":(off["RegularcountP"]  || "0").toString(),
            location: {
              type: 'Point',
              coordinates: [off["Longitude"],off["Latitude"]],
            } 
          }
        }
      });
    })
    
    onCreate();
    // console.log("checker >>>", e);
  };

  const fieldsToRender = useMemo(() => ([
    { type: 'text', label: 'Business Group  Name', id: 'businessgroupname', name: 'businessgroupname', helpText: 'Business Group', colClass: "col-sm-4 col-4", },
    { type: 'text', label: 'Location Name', id: 'locationname', name: 'locationname', helpText: 'locationname', colClass: "col-sm-4 col-4", },
    { type: 'text', label: 'Number of employees', id: 'numberofemployees', name: 'numberofemployees', helpText: 'Number of Employees', colClass: "col-sm-4 col-4", },
    { type: 'text', label: 'Business Group ID', id: 'businessgroupid', name: 'businessgroupid', helpText: 'Business Group id', colClass: "col-sm-4 col-4", },
    { type: 'text', label: 'Location ID', id: 'locationid', name: 'locationid', helpText: 'Location ID', colClass: "col-sm-4 col-4", },
  ]), [])

  const country = watch('country');
  const employeeOffice = watch('country');
  const city = watch('country');

  const handleAddress = (addressData) => {
    console.log(addressData)
    const countryEntry = addressData.find(addArray => addArray?.types?.includes("country"))
    const cityEntry = addressData.find(addArray => addArray?.types?.includes("administrative_area_level_2"))
    const employeeOfficeEntry = addressData.find(addArray => addArray?.types?.includes("locality"))
    setValue('country', countryEntry ? countryEntry['long_name'] : "")
    setValue('city', cityEntry ? cityEntry['long_name'] : "")
    setValue('employeeOfficeName', employeeOfficeEntry ? employeeOfficeEntry['long_name'] : "")
  }

  return (
    <CRow>

      <CCol xs={12}>
        <CCard className="mb-4">
          <CCardHeader>
            <strong>Business Group</strong>
          </CCardHeader>
          <CCardBody>
            <p className="text-medium-emphasis small">
              New Business Group
            </p>
            <CForm
              onSubmit={handleSubmit((e) => {
                onSubmit(getValues());
                reset(null);
              })}
            >
                <FormProvider {...employeeOfficemethords}>
              <CCol className={'mb-3'} xs={6}>
                <MapComponents
                  type='PlacedAutoComplete'
                  withLatLng={setLatLang}
                  handleAddress={handleAddress}
                />
              </CCol>
              <RenderFormFields
                fields={fieldsToRender}
                register={register}
              />
              <CCol className="my-2" xs={6}>
                <MapComponents
                  markers={[{ points: selectedLatLng }]}
                  center={selectedLatLng || undefined}
                />
              </CCol>
              <>
                <FileUploaderInput
                  setResponseUrl={(data) => setServerImgUrl(data[0])}
                  Label="Picture"
                />
              </>
              </FormProvider>
              <CButton type="submit" color="primary">
                Submit
              </CButton>
            </CForm>

          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  )
}

CreateYachtType.propTypes = {
  onCreate: PropTypes.func,
}
export default CreateYachtType;
