
export default {
   apiurl: 'http://10.10.158.47:4000'
 // apiurl: 'https://joinyasalam.com/yatch'
}
